# CHANGELOG

<a name="v1.0.3"></a>
## [v1.0.3] - 2022-03-01

### Maintenance

- Bump golang.org/x/text to v0.3.7 due to CVE-2021-38561

<a name="v1.0.2"></a>
## [v1.0.2] - 2021-03-27

### Maintenance

- Change minimum Go version to 1.11

<a name="v1.0.1"></a>
## [v1.0.1] - 2021-03-24

### Bug Fixes

- Add go.mod file

<a name="v1.0.0"></a>
## [v1.0.0] - 2018-02-21

[v1.0.2]: https://github.com/xdg-go/stringprep/releases/tag/v1.0.2
[v1.0.1]: https://github.com/xdg-go/stringprep/releases/tag/v1.0.1
[v1.0.0]: https://github.com/xdg-go/stringprep/releases/tag/v1.0.0
